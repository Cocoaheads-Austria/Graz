//
//  MainViewController.m
//  Untitled
//
//  Created by Herbert on 14.12.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"


@implementation MainViewController
@synthesize btn;
@synthesize progressView;



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	[super viewDidLoad];
	[btn addTarget:self action:@selector(handleButtonPress:) forControlEvents:UIControlEventTouchDown]; 
	progressView.progress = 0.0f;
}



- (IBAction) handleButtonPress:(id)sender
{
	//Block structure
	//^ returntype (arguments) {Body;}

	//1. Declaring block, reusing
//	int multiplier = 2;
//	int (^myBlock)(int) = ^(int num) {
//		return num * multiplier;
//	};
//	int result=1;
//	for (int i=1; i<100; ++i, result<1.01f) {
//		result+=myBlock(i);
//		float progress=(float)result/256.0f;
//		progressView.progress = progress;
//	}

//2. inferring blocks
//	int multiplier = 2;
//	int (^myBlock)(int) = ^(int num) {
//		return num * multiplier;
//	};
//	
//	void (^myOtherBlock)(int) = ^(int loopCount) {
//	int result=1;
//	  for (int i=1; i<loopCount; ++i, result<1.01f) 
//	  {
//		  result+=myBlock(i);
//		  float progress=(float)result/256.0f;
//		  progressView.progress = progress;
//	  }
//	};
//	myOtherBlock(100);
//	myOtherBlock(200);
//	myOtherBlock(500);
	
// 3. dissecting and composing blocks	

//	int multiplier = 2;	
//	typedef  int (^multiplier_t)(int);
//	typedef	 void (^looper_t)(int, multiplier_t);
	
//	multiplier_t multiplierblock=^(int num) {
//				return num * multiplier;
//			};
	
//	looper_t looperblock=^(int loopCount, multiplier_t theMultiplier)
//	{
//			int result=1;
//			  for (int i=1; i<loopCount; ++i, result<1.01f) 
//			  {
//				  result+=theMultiplier(i);
//				  float progress=(float)result/256.0f;
//				  progressView.progress = progress;
//			  }
//	};
//	looperblock(100, multiplierblock);

//4. composing (ii)	
//	int multiplier = 2;	
//	typedef  int (^multiplier_t)(int);
//	typedef	 void (^looper_t)(int, multiplier_t);
	
//	multiplier_t multiplierblock=^(int num) {
//		return num * multiplier;
//	};
//
//	multiplier_t multiplierblock2=^(int num) {
//		return num * multiplier + 1;
//	};
	
//	looper_t looperblock=^(int loopCount, multiplier_t theMultiplier)
//	{
//		int result=1;
//		for (int i=1; i<loopCount; ++i, result<1.01f) 
//		{
//			result+=theMultiplier(i);
//			float progress=(float)result/256.0f;
//			progressView.progress = progress;
//		}
//	};
//	progressView.progress = 0.0f;
//	looperblock(100, multiplierblock);
//	progressView.progress = 0.0f;
//	looperblock(100, multiplierblock2);

//5. Introducing gcd
//Queues - implicit blocks
// 1. Mainqueue
// 2. Threadpool Queues Concurrent queues (System)
// 3. Own queues serial queues
	/////	void (^myBlock)(int) = ^ (int num){
	/////	};
	
//From Sample 1.	
//different queues
//dispatch_sync
//dispatch_async
/*A
	//Get gloabl concurrentqueue, normal priority
	dispatch_queue_t myConcurrentQueue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0);
	
	//Create custom serial queue
	dispatch_queue_t mySerialQueue=dispatch_queue_create("com.chg.MySerialQueue", NULL);

	//Access globa serial queue at runtime
//	dispatch_queue_t myReferenceToMyQueue=
	
	for (int i=1; i<6; ++i) {
		dispatch_async(myConcurrentQueue,^{
		[NSThread sleepForTimeInterval:2.0];
		progressView.progress = 20*i;//this might crash
		});
		}
A*/
/*B
//Get gloabl concurrentqueue, normal priority
	dispatch_queue_t myConcurrentQueue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0);
	
	//Access globa serial queue at runtime
	//	dispatch_queue_t myReferenceToMyQueue=
	progressView.progress = 0;

	for (int i=1; i<6; ++i) {
		dispatch_async(myConcurrentQueue,^{
			[NSThread sleepForTimeInterval:0.01];
			dispatch_async(dispatch_get_main_queue(),^{
			progressView.progress = 20*i/100.0f;
			});
		});
	}
B*/	

///*C
	[btn 
	progressView.progress = 0;
	//Create custom serial queue
	dispatch_queue_t mySerialQueue=dispatch_queue_create("com.chg.MySerialQueue", NULL);

	for (int i=1; i<6; ++i) {
		dispatch_async(mySerialQueue,^{
			[NSThread sleepForTimeInterval:2.0];
			dispatch_async(dispatch_get_main_queue(),^{
				progressView.progress = 20.0f*(float)i/100.0f;
			});
		});
	}
//C*/	
	

//6. Block and GCD in Cocoatouch
//NSOperationqueue
//NSBlockOperation
	
	
	
	
}



- (void)flipsideViewControllerDidFinish:(FlipsideViewController *)controller {
    
	[self dismissModalViewControllerAnimated:YES];
}


- (IBAction)showInfo:(id)sender {    
	
	FlipsideViewController *controller = [[FlipsideViewController alloc] initWithNibName:@"FlipsideView" bundle:nil];
	controller.delegate = self;
	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc. that aren't in use.
}


- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)dealloc {
    [super dealloc];
}


@end
