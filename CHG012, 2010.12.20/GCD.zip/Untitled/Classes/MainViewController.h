//
//  MainViewController.h
//  Untitled
//
//  Created by Herbert on 14.12.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate> {
	IBOutlet UIButton* btn;
	IBOutlet UIProgressView* progressView;

}


@property (nonatomic, retain) IBOutlet UIButton *btn;
@property (nonatomic, retain) IBOutlet UIProgressView *progressView;
- (IBAction)showInfo:(id)sender;
- (IBAction) handleButtonPress:(id)sender;

@end
